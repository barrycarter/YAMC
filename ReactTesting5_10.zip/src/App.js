import React, { Component } from 'react'
import './App.css'

class App extends Component {

  constructor(props) {
    super(props);
    this.ns={};
    this.state = {lat: 0, lng: 0};
    }
  

  f = event => {

    if (event.target.id === 'lat') {
      this.setState({lat: event.target.value})
    } else if (event.target.id === 'latDeg') {
      console.log("LATDEG", event.target.value);
      this.setState({lat: event.target.value + this.ns.latMin/60 + this.ns.latSec/3600})
      console.log("EVT", event.target.value);
      console.log("STATE", this.state.lat);
    } else {
        console.log("WTF?");
    }

    console.log(event.target);
  }

  render () {

    this.ns.latDeg = Math.floor(this.state.lat);
    this.ns.latMin = Math.floor(60*(this.state.lat-this.ns.latDeg))
    this.ns.latSec = Math.floor(3600*(this.state.lat-this.ns.latDeg-this.ns.latMin/60))

    return (
      <div className='App'>
      <div>
          Latitude
          <input id='lat' onChange={this.f} type='text' value={this.state.lat} />
          <input id='latDeg' onChange={this.f} size='2' type='text' value={this.ns.latDeg} />
          <input id='latMin' onChange={this.f} size='2' type='text' value={this.ns.latMin} />
          <input id='latSec' onChange={this.f} size='2' type='text' value={this.ns.latSec} />
          </div>
          <div>
          Longitude
          <input id='lng' onChange={this.f} type='text' value={this.state.lng} />
          <input id='lngDeg' onChange={this.f} size='2' type='text' value={this.ns.lngDeg} />
          <input id='lngMin' onChange={this.f} size='2' type='text' value={this.ns.lngMin} />
          <input id='lngSec' onChange={this.f} size='2' type='text' value={this.ns.lngSec} />
</div>
<div>
          X <input id='x' onChange={this.f} type='text' value={this.ns.x} />
          Y <input id='y' onChange={this.f} type='text' value={this.ns.y} />
          </div>
      </div>
    )
  }
}

export default App
