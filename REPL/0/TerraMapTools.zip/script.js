moveCenter();

function moveCenter() {
  map.setCenter({lat: -34, lng: 151});
}

var rect = new google.maps.Rectangle();
